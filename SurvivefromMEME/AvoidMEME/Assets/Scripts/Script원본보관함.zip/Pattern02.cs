using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class Pattern02 : MonoBehaviour
{
    [SerializeField]
    private GameObject[] warningImages; // ��� �̹���

    [SerializeField]
    private GameObject[] playerObjects; // �÷��̾� ������Ʈ

    [SerializeField]
    private GameObject[] bg; // �÷��̾� ������Ʈ

    public AudioSource audioSource;


    private void OnEnable()
    {
        StartCoroutine(nameof(Process));
        //audioSource.Play(); // ���� ����
    }
    private void OnDisable()
    {

        StopCoroutine(nameof(Process));
    }
    
    private IEnumerator Process()
    {
        
        bg[0].SetActive(true);
        yield return new WaitForSeconds(1f);
           bg[0].SetActive(false);
           if (bg[0].activeSelf == false) 
           {
               bg[1].SetActive(true);
               yield return new WaitForSeconds(1f);
                   bg[1].SetActive(false);
                }

        yield return new WaitForSeconds(1f);
       

        warningImages[0].SetActive(true);
        
        yield return new WaitForSeconds(0.3f);
           warningImages[0].SetActive(false);
           if (warningImages[0].activeSelf == false) 
           {
               warningImages[1].SetActive(true);
               yield return new WaitForSeconds(0.2f);
                   warningImages[1].SetActive(false);
                   if (warningImages[1].activeSelf == false) 
                   {
                        warningImages[2].SetActive(true);
                        yield return new WaitForSeconds(0.2f);
                           warningImages[2].SetActive(false);
                   }
                         
           }

        yield return new WaitForSeconds(0.2f);
            playerObjects[0].SetActive(true);
            playerObjects[0].GetComponent<MovementTransform2D>().MoveTo(Vector3.up);

            yield return new WaitForSeconds(0.4f);
                playerObjects[0].SetActive(false);
                if (playerObjects[0].activeSelf == false)
                {
                    playerObjects[1].SetActive(true);
                    playerObjects[1].GetComponent<MovementTransform2D>().MoveTo(Vector3.up);
                    yield return new WaitForSeconds(0.3f);
                        playerObjects[1].SetActive(false);
                        if (playerObjects[1].activeSelf == false)
                        {
                            playerObjects[2].SetActive(true);
                            playerObjects[2].GetComponent<MovementTransform2D>().MoveTo(Vector3.up);
                            yield return new WaitForSeconds(0.3f);
                                playerObjects[2].SetActive(false);
                        }

                }
        warningImages[0].SetActive(true);

        yield return new WaitForSeconds(0.2f);
            warningImages[0].SetActive(false);
            if (warningImages[0].activeSelf == false)
            {
                warningImages[1].SetActive(true);
                yield return new WaitForSeconds(0.3f);
                    warningImages[1].SetActive(false);
                    if (warningImages[1].activeSelf == false)
                    {
                        warningImages[2].SetActive(true);
                        yield return new WaitForSeconds(0.3f);
                            warningImages[2].SetActive(false);
                    }

            }

        yield return new WaitForSeconds(0.3f);
            playerObjects[3].SetActive(true);
            playerObjects[3].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);

            yield return new WaitForSeconds(0.3f);
                playerObjects[3].SetActive(false);
                if (playerObjects[3].activeSelf == false)
                {
                    playerObjects[4].SetActive(true);
                    playerObjects[4].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);
                    yield return new WaitForSeconds(0.3f);
                        playerObjects[4].SetActive(false);
                        if (playerObjects[4].activeSelf == false)
                        {
                            playerObjects[5].SetActive(true);
                            playerObjects[5].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);
                            yield return new WaitForSeconds(0.3f);
                                playerObjects[5].SetActive(false);
                                
                        }

                }

        warningImages[0].SetActive(true);
        warningImages[2].SetActive(true);

        yield return new WaitForSeconds(0.5f);
            warningImages[0].SetActive(false);
            warningImages[2].SetActive(false);
            if (warningImages[0].activeSelf == false)
            {
                warningImages[1].SetActive(true);
                yield return new WaitForSeconds(0.4f);
                    warningImages[1].SetActive(false);


            }


        yield return new WaitForSeconds(0.2f);
            playerObjects[0].SetActive(true);
            playerObjects[0].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);
            playerObjects[2].SetActive(true);
            playerObjects[2].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);

            yield return new WaitForSeconds(0.3f);
                playerObjects[0].SetActive(false);
                playerObjects[2].SetActive(false);
                if (playerObjects[0].activeSelf == false)
                {
                    playerObjects[4].SetActive(true);
                    playerObjects[4].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);
                    yield return new WaitForSeconds(0.3f);
                        playerObjects[4].SetActive(false);


                }
        yield return new WaitForSeconds(0.3f);
        bg[2].SetActive(true);
            yield return new WaitForSeconds(1f);
                bg[2].SetActive(false);
                if (bg[2].activeSelf == false)
                {
                    bg[3].SetActive(true);
                    yield return new WaitForSeconds(0.5f);
                        bg[3].SetActive(false);
                }

        warningImages[3].SetActive(true);
        
        yield return new WaitForSeconds(0.3f);
            warningImages[3].SetActive(false);
        
            if (warningImages[3].activeSelf == false)
            {
                warningImages[4].SetActive(true);
                yield return new WaitForSeconds(0.3f);
                    warningImages[4].SetActive(false);


            }
        yield return new WaitForSeconds(0.2f);
            playerObjects[7].SetActive(true);
            playerObjects[7].GetComponent<MovementTransform2D>().MoveTo(Vector3.right);
            
            yield return new WaitForSeconds(0.5f);
                
                playerObjects[7].SetActive(false);
                
                if (playerObjects[7].activeSelf == false)
                {
                    warningImages[2].SetActive(true);
                    yield return new WaitForSeconds(0.2f);
                        playerObjects[6].SetActive(true);
                        playerObjects[6].GetComponent<MovementTransform2D>().MoveTo(Vector3.left);
                        warningImages[2].SetActive(false);
                        yield return new WaitForSeconds(0.4f);
                            playerObjects[6].SetActive(false);
                            if (playerObjects[6].activeSelf == false)
                            { 
                                playerObjects[5].SetActive(true);
                                playerObjects[5].GetComponent<MovementTransform2D>().MoveTo(Vector3.down);
                                yield return new WaitForSeconds(0.4f);
                                    playerObjects[5].SetActive(false);
                            }

                }


        yield return new WaitForSeconds(3f);

            gameObject.SetActive(false);


    }
}
